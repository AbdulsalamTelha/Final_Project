// content-[resolved-dynamic-negative]
