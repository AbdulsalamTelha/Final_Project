let path = require('path')

module.exports = {
  plugins: [require(path.resolve('..', '..'))],
}
