module.exports = {
  content: ['./src/index.html', './src/glob/*.{js,html}'],
  theme: {
    extend: {},
  },
  corePlugins: {
    preflight: false,
  },
  plugins: [],
}
