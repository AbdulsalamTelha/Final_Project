/** @type {import('tailwindcss').Config} */
export default __CONFIG__
